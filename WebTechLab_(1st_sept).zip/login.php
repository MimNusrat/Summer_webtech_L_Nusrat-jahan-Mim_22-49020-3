<?php
session_start();

// Preset credentials
$validUser = "admin";
$validPass = "12345";

// Check which button was clicked
if (isset($_POST["action"])) {
    $action = $_POST["action"];

    if ($action === "Login") {
        // If empty fields → go to error page
        if (empty($_POST["username"]) || empty($_POST["password"])) {
            header("Location: error.php");
            exit();
        }

        $username = trim($_POST["username"]);
        $password = trim($_POST["password"]);

        // Validate credentials
        if ($username === $validUser && $password === $validPass) {
            $_SESSION["username"] = $username;
            $_SESSION["password"] = $password;
            header("Location: userinfo.php");
            exit();
        } else {
            header("Location: error.php");
            exit();
        }
    } elseif ($action === "Logout") {
        // Clear session
        session_unset();
        session_destroy();
        header("Location: home.php");
        exit();
    }
}