<?php
// Start session-like behavior with cookies
$cookieName = "mycookie";
$cookieValue = "nusrat";

if (!isset($_COOKIE[$cookieName])) {
    // Cookie not set yet → set it now
    setcookie($cookieName, $cookieValue, time() + 10, "/"); // valid 10 sec
    $displayText = "Not found";
} else {
    // Cookie exists → display its value
    $displayText = $_COOKIE[$cookieName];
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Cookie1</title>
</head>
<body>
    <h1><b>Cookie Set</b></h1>
    <p><?php echo $displayText; ?></p>
    <p><a href="cookie2.php">Go to Cookie2</a></p>
</body>
</html>