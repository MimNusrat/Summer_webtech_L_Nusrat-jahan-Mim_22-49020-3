<!DOCTYPE html>
<html>
<head>
    <title>Error</title>
</head>
<body>
    <h2 style="color:red;">Error!</h2>
    <p>Invalid login. Please try again.</p>
    <p><a href="home.php">Back to Home</a></p>
</body>
</html>