<?php
session_start();
if (!isset($_SESSION["username"])) {
    // Not logged in
    header("Location: home.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Info</title>
</head>
<body>
    <h2>User Information</h2>
    <p><strong>Username:</strong> <?php echo $_SESSION["username"]; ?></p>
    <p><strong>Password:</strong> <?php echo $_SESSION["password"]; ?></p>
    <p><a href="home.php">Back to Home</a></p>
</body>
</html>