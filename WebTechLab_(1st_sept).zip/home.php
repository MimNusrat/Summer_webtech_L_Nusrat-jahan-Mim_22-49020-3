<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>
    <h2>Home Page</h2>

    <ul>
        <li><a href="cookie1.php">Go to Cookie1</a></li>
        <li><a href="cookie2.php">Go to Cookie2</a></li>
    </ul>

    <h3>Login Form</h3>
    <form method="POST" action="login.php">
        <label>Username:</label>
        <input type="text" name="username"><br><br>

        <label>Password:</label>
        <input type="password" name="password"><br><br>

        <input type="submit" name="action" value="Login">
        <input type="submit" name="action" value="Logout">
    </form>
</body>
</html>