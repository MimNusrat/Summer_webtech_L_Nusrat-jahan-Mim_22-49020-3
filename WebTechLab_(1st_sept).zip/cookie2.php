<?php
$cookieName = "mycookie";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cookie2</title>
</head>
<body>
    <h1>Cookie Value</h1>
    <p>
        <?php
        if (isset($_COOKIE[$cookieName])) {
            echo "Cookie Value: " . $_COOKIE[$cookieName];
        } else {
            echo "No cookie found!";
        }
        ?>
    </p>
</body>
</html>