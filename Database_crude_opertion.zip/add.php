<?php
$conn = new mysqli("localhost", "root", "", "student_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $age = intval($_POST['age']);
    $course = $conn->real_escape_string($_POST['course']);
    
    $conn->query("INSERT INTO students (name, age, course) VALUES ('$name', $age, '$course')");
}

header("Location: index.php");
exit;
?>
