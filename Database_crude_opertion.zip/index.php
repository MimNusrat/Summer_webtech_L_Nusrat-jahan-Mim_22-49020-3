<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "student_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Delete operation
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM students WHERE id=$id");
    header("Location: index.php");
    exit;
}

// Fetch all students
$result = $conn->query("SELECT * FROM students");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Informations</title>
    <style>
        table { border-collapse: collapse; width: 70%; margin: 20px auto; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        th { background-color: #f2f2f2; }
        a { text-decoration: none; padding: 5px 10px; background: #007bff; color: white; border-radius: 4px;}
        a.delete { background: #dc3545; }
        a:hover { opacity: 0.8; }
        form { margin: 20px auto; width: 70%; }
        input[type="text"], input[type="number"] { padding: 5px; margin: 5px; width: 200px; }
        input[type="submit"] { padding: 7px 15px; background-color: #28a745; color: white; border: none; cursor: pointer;}
        input[type="submit"]:hover { background-color: #218838;}
    </style>
</head>
<body>

<h2 style="text-align:center;">Student Informations</h2>

<table>
    <thead>
        <tr>
            <th>ID</th><th>Name</th><th>Age</th><th>Course</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= $row['age'] ?></td>
            <td><?= htmlspecialchars($row['course']) ?></td>
            <td>
                <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> | 
                <a href="index.php?delete=<?= $row['id'] ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<h3 style="text-align:center;">Add New Student</h3>
<form action="add.php" method="post" style="text-align:center;">
    <input type="text" name="name" placeholder="Name" required />
    <input type="number" name="age" placeholder="Age" required />
    <input type="text" name="course" placeholder="Course" required />
    <input type="submit" value="Add Student" />
</form>

</body>
</html>
