<?php
$conn = new mysqli("localhost", "root", "", "student_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = intval($_GET['id']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $age = intval($_POST['age']);
    $course = $conn->real_escape_string($_POST['course']);
    
    $conn->query("UPDATE students SET name='$name', age=$age, course='$course' WHERE id=$id");
    header("Location: index.php");
    exit;
}

$result = $conn->query("SELECT * FROM students WHERE id=$id");
if ($result->num_rows == 0) {
    echo "Student not found!";
    exit;
}

$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Edit Student</title>
    <style>
        form { margin: 20px auto; width: 300px; }
        input[type="text"], input[type="number"] { padding: 5px; margin: 5px 0; width: 100%; }
        input[type="submit"] { padding: 7px 15px; background-color: #007bff; color: white; border: none; cursor: pointer;}
        input[type="submit"]:hover { background-color: #0056b3;}
    </style>
</head>
<body>

<h2 style="text-align:center;">Edit Student</h2>

<form action="" method="post">
    <label>Name:</label><br/>
    <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" required /><br/>
    
    <label>Age:</label><br/>
    <input type="number" name="age" value="<?= $student['age'] ?>" required /><br/>
    
    <label>Course:</label><br/>
    <input type="text" name="course" value="<?= htmlspecialchars($student['course']) ?>" required /><br/>
    
    <input type="submit" value="Update" />
</form>

<p style="text-align:center;"><a href="index.php">Back to List</a></p>

</body>
</html>
